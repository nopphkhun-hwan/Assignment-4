const form = document.getElementById('regForm');
const successBox = document.getElementById('success');
const pwInput = document.getElementById('password');
const togglePw = document.getElementById('togglePw');
const meterBar = document.getElementById('meterBar');

// each rule returns an error message, or '' when valid
const rules = {
  name: v => (v.trim() ? '' : 'Full name is required'),
  email: v => (v.includes('@') && v.includes('.') ? '' : "Email must contain '@' and '.'"),
  password: v => (v.length >= 8 ? '' : 'Password must be at least 8 characters'),
  confirm: v => (v && v === pwInput.value ? '' : 'Passwords do not match'),
  phone: v => (/^\d{10}$/.test(v) ? '' : 'Phone must be exactly 10 digits'),
};

function validate(id) {
  const input = document.getElementById(id);
  const msg = rules[id](input.value);
  document.getElementById(`${id}Error`).textContent = msg;
  input.classList.toggle('invalid', !!msg);
  input.classList.toggle('valid', !msg);
  return !msg;
}

function updateMeter(pw) {
  let score = 0;
  if (pw.length >= 8) score++;
  if (/[A-Z]/.test(pw) && /[a-z]/.test(pw)) score++;
  if (/\d/.test(pw)) score++;
  if (/[^A-Za-z0-9]/.test(pw)) score++;

  const levels = [
    { w: '0%', c: 'transparent' },
    { w: '33%', c: '#dc2626' },
    { w: '33%', c: '#dc2626' },
    { w: '66%', c: '#eab308' },
    { w: '100%', c: '#16a34a' },
  ];
  const { w, c } = levels[pw ? score : 0];
  meterBar.style.width = w;
  meterBar.style.background = c;
}

Object.keys(rules).forEach(id => {
  document.getElementById(id).addEventListener('input', () => {
    validate(id);
    // keep confirm in sync when password changes
    if (id === 'password') {
      updateMeter(pwInput.value);
      if (document.getElementById('confirm').value) validate('confirm');
    }
  });
});

togglePw.addEventListener('click', () => {
  const show = pwInput.type === 'password';
  pwInput.type = show ? 'text' : 'password';
  togglePw.classList.toggle('on', show);
  togglePw.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
});

form.addEventListener('submit', e => {
  e.preventDefault();
  // validate all fields (no short-circuit so every error shows)
  const ok = Object.keys(rules).map(validate).every(Boolean);
  if (!ok) return;

  const name = document.getElementById('name').value.trim();
  successBox.textContent = `Welcome, ${name}! Registration successful 🎉`;
  successBox.hidden = false;
  form.reset();
  updateMeter('');
  form.querySelectorAll('input').forEach(i => i.classList.remove('valid', 'invalid'));
});
